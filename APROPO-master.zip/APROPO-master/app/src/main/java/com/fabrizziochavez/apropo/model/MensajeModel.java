package com.fabrizziochavez.apropo.model;

/**
 * Created by fabri on 1/05/2017.
 */

public class MensajeModel {
    private int coderror;
    private String mensaje;
    public int getCoderror() {
        return coderror;
    }

    public void setCoderror(int coderror) {
        this.coderror = coderror;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }


}
